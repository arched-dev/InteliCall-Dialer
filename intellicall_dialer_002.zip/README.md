# InteliCall-Dialer
Chrome extension to make tel links dialable on the InteliCall system.


