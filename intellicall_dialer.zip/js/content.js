chrome.storage.sync.get(['url'], function(result) {
  if (result.url) {
    var links = document.querySelectorAll('a[href^="tel:"]');
    for (var i = 0; i < links.length; i++) {
      links[i].addEventListener('click', function(e) {
        // Prevent the default action
        e.preventDefault();

        // Extract the telephone number from the link
        var tel = this.getAttribute('href').substring(4);

        // Create the new URL
        var newUrl = "https://" + result.url + tel;

        // Fetch the new URL
        fetch(newUrl, {
          method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
          console.log(data);
        })
        .catch(error => console.error('Error:', error));
      });
    }
  }
});
